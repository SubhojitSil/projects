package com.capgemini.mobileShop.bean;

import java.time.LocalDate;
import java.util.Date;

public class PurchaseDetails {
	private int purchaseId;
	private String custname;
	private String custMailId;
	private String custPhoneNo;
	private LocalDate purchaseDate;
	private int mobileID;

	public PurchaseDetails() {
	}

	public PurchaseDetails(int purchaseId, String custname, String custMailId,
			String custPhoneNo, LocalDate purchaseDate, int mobileId) {
		this.purchaseId = purchaseId;
		this.custname = custname;
		this.custMailId = custMailId;
		this.custPhoneNo = custPhoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileID = mobileId;
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getCustMailId() {
		return custMailId;
	}

	public void setCustMailId(String custMailId) {
		this.custMailId = custMailId;
	}

	public String getCustPhoneNo() {
		return custPhoneNo;
	}

	public void setCustPhoneNo(String custPhoneNo) {
		this.custPhoneNo = custPhoneNo;
	}

	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public int getMobileID() {
		return mobileID;
	}

	public void setMobileID(int mobileID) {
		this.mobileID = mobileID;
	}

	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", custname="
				+ custname + ", custMailId=" + custMailId + ", custPhoneNo="
				+ custPhoneNo + ", purchaseDate=" + purchaseDate
				+ ", mobileID=" + mobileID + "]";
	}

}
