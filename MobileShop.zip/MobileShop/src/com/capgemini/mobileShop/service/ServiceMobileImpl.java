package com.capgemini.mobileShop.service;

import java.util.List;

import com.capgemini.mobileShop.bean.Mobiles;
import com.capgemini.mobileShop.dao.IMobileDAO;
import com.capgemini.mobileShop.dao.IPurchaseDetailsDAO;
import com.capgemini.mobileShop.dao.MobileDAOImpl;
import com.capgemini.mobileShop.dao.PurchaseDetailsDaoImpl;
import com.capgemini.mobileShop.exception.MobilePurchaseException;

public class ServiceMobileImpl implements IServiceMobile {
	private IMobileDAO mobileDAO;
	public ServiceMobileImpl(){
		mobileDAO= new MobileDAOImpl();
	}
	@Override
	public List<Mobiles> viewAll() throws MobilePurchaseException {
		 List<Mobiles> mobileList = mobileDAO.viewAll();
		 
		return mobileList;
	}

	@Override
	public boolean deleteMobile(int mobileId) throws MobilePurchaseException {
		IPurchaseDetailsDAO purchaseDetailDao = new PurchaseDetailsDaoImpl();
		boolean isPurchaseDeleted = purchaseDetailDao.deletePurchaseDetail(mobileId);
		boolean isDeleted = mobileDAO.deleteMobile(mobileId);
		return (isDeleted && isPurchaseDeleted);
	}

	@Override
	public List<Mobiles> search(float minPrice, float maxprice)
			throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return null;
	}

}
