package com.capgemini.mobileShop.service;

import java.util.List;

import com.capgemini.mobileShop.bean.Mobiles;
import com.capgemini.mobileShop.exception.MobilePurchaseException;

public interface IServiceMobile {

	public List<Mobiles> viewAll() throws MobilePurchaseException;

	public boolean deleteMobile(int mobileId) throws MobilePurchaseException;

	public List<Mobiles> search(float minPrice, float maxprice)
			throws MobilePurchaseException;

}
