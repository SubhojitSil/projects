package com.capgemini.mobileShop.service;

import com.capgemini.mobileShop.bean.PurchaseDetails;
import com.capgemini.mobileShop.dao.IPurchaseDetailsDAO;
import com.capgemini.mobileShop.dao.PurchaseDetailsDaoImpl;
import com.capgemini.mobileShop.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetails purchaseDetails)
			throws MobilePurchaseException {
		IPurchaseDetailsDAO purchaseDetailsDao = new PurchaseDetailsDaoImpl();
		
		boolean isItInserted = purchaseDetailsDao.insertPurchaseDetail(purchaseDetails); 
				return isItInserted;
	}

}
