package com.capgemini.mobileShop.exception;

public class MobilePurchaseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1596215507121325878L;

	public MobilePurchaseException(){
		super();
	}

	public MobilePurchaseException(String message) {
		super(message);
	}
	
	
}
