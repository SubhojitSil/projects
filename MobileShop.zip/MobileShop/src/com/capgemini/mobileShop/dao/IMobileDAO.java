package com.capgemini.mobileShop.dao;

import java.util.List;

import com.capgemini.mobileShop.bean.Mobiles;
import com.capgemini.mobileShop.exception.MobilePurchaseException;

public interface IMobileDAO {

	public boolean updateMobile(final int mobileId, final int quantity)
			throws MobilePurchaseException;

	public List<Mobiles> viewAll() throws MobilePurchaseException;

	public boolean deleteMobile(final int mobileId) throws MobilePurchaseException;

	public List<Mobiles> search(final float minPrice, final float maxPrice)
			throws MobilePurchaseException;
}
