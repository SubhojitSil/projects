package com.capgemini.mobileShop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.mobileShop.bean.Mobiles;
import com.capgemini.mobileShop.exception.MobilePurchaseException;
import com.capgemini.mobileShop.util.DBConnection;

public class MobileDAOImpl implements IMobileDAO {

	@Override
	public boolean updateMobile(int mobileId, int quantity)
			throws MobilePurchaseException {
		int records = 0;
		boolean isUpdated = false;
		try (Connection connMobile = DBConnection.getInstance().getConnection();

				PreparedStatement preparedStatement = connMobile
						.prepareStatement(QueryMaperMobile.UPDATE_MOBILE);) {

			preparedStatement.setInt(1, quantity);
			preparedStatement.setInt(2, mobileId);

			records = preparedStatement.executeUpdate();

			if (records > 0) {
				isUpdated = true;
			}

		} catch (SQLException sqlEx) {
			throw new MobilePurchaseException();
		}

		return isUpdated;
	}

	@Override
	public List<Mobiles> viewAll() throws MobilePurchaseException {
		
		
		List<Mobiles> mobileList = new ArrayList<Mobiles>();
		try (Connection connMobile = DBConnection.getInstance().getConnection();

				PreparedStatement preparedStatement = connMobile
						.prepareStatement(QueryMaperMobile.VIEW_MOBILE);
				ResultSet rsMobiles = preparedStatement.executeQuery();) {

			while (rsMobiles.next()) {
				Mobiles mobile = new Mobiles();

				mobile.setMobileid(rsMobiles.getInt("mobileid"));
				mobile.setName(rsMobiles.getString("name"));
				mobile.setPrice(rsMobiles.getFloat("price"));
				mobile.setQuantity(rsMobiles.getInt("quantity"));

				mobileList.add(mobile);
			}
			if(mobileList.size() == 0){
				throw new MobilePurchaseException("No Record Found");
			}
		} catch (SQLException sqlEx) {
			throw new MobilePurchaseException();
		}

		return mobileList;
	}

	@Override
	public boolean deleteMobile(int mobileId) throws MobilePurchaseException {
		int records = 0;
		boolean isDeleted = false;
		try (Connection connMobile = DBConnection.getInstance().getConnection();

				PreparedStatement preparedStatement = connMobile
						.prepareStatement(QueryMaperMobile.DELETE_MOBILE);) {

			preparedStatement.setInt(2, mobileId);

			records = preparedStatement.executeUpdate();

			if (records > 0) {
				isDeleted = true;
			}

		} catch (SQLException sqlEx) {
			throw new MobilePurchaseException();
		}

		return isDeleted;
	}

	@Override
	public List<Mobiles> search(float minPrice, float maxPrice)
			throws MobilePurchaseException {
		List<Mobiles> mobileList = new ArrayList<Mobiles>();
		try (Connection connMobile = DBConnection.getInstance().getConnection();

				PreparedStatement preparedStatement = connMobile
						.prepareStatement(QueryMaperMobile.SEARCH_MOBILE);
				
				) {
			preparedStatement.setFloat(1, minPrice);
			preparedStatement.setFloat(2, maxPrice);
			ResultSet rsMobiles = preparedStatement.executeQuery();
		
			while (rsMobiles.next()) {
				Mobiles mobile = new Mobiles();

				mobile.setMobileid(rsMobiles.getInt("mobileid"));
				mobile.setName(rsMobiles.getString("name"));
				mobile.setPrice(rsMobiles.getFloat("price"));
				mobile.setQuantity(rsMobiles.getInt("quantity"));

				mobileList.add(mobile);
			}
			if(mobileList.size() == 0){
				throw new MobilePurchaseException("No Record Found");
			}
		} catch (SQLException sqlEx) {
			throw new MobilePurchaseException();
		}

		return mobileList;
	}

}
