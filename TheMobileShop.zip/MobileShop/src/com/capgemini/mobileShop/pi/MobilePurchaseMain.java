package com.capgemini.mobileShop.pi;

import java.time.LocalDate;

import com.capgemini.mobileShop.bean.PurchaseDetails;
import com.capgemini.mobileShop.exception.MobilePurchaseException;
import com.capgemini.mobileShop.service.IServiceMobile;
import com.capgemini.mobileShop.service.IServicePurchaseMobile;
import com.capgemini.mobileShop.service.ServicePurchaseImpl;

public class MobilePurchaseMain {

	public static void main(String[] args) {
		PurchaseDetails pdb = new PurchaseDetails("abc", "abc@ac.com",
				"9876543210",1002);
            IServicePurchaseMobile isp = new ServicePurchaseImpl();
            
            try{
            	boolean isInserted = isp.insertPurchaseDetails(pdb);
            	if(isInserted){
            		System.out.println("record inserted Successfully");
            	}
            }catch(MobilePurchaseException mpe){
            	System.out.println(mpe.getMessage());
            }
	}

}
