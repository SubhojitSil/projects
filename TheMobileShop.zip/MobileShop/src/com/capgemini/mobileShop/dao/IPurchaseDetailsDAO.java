package com.capgemini.mobileShop.dao;

import com.capgemini.mobileShop.bean.PurchaseDetails;
import com.capgemini.mobileShop.exception.MobilePurchaseException;

public interface IPurchaseDetailsDAO {
	public boolean insertPurchaseDetail( PurchaseDetails purchaseDetails)
			throws MobilePurchaseException;

	public boolean deletePurchaseDetail(final int mobileid)
			throws MobilePurchaseException;

}
