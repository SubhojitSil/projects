package com.capgemini.mobileShop.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.mobileShop.bean.PurchaseDetails;
import com.capgemini.mobileShop.exception.MobilePurchaseException;
import com.capgemini.mobileShop.util.DBConnection;

public class PurchaseDetailsDaoImpl implements IPurchaseDetailsDAO {

	@Override
	public boolean insertPurchaseDetail(PurchaseDetails purchaseDetails)
			throws MobilePurchaseException {
		int records=0;
		boolean isInserted = false;
		try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement= 
				connPurchaseDetails.prepareStatement
				(QueryMaperPurchaseDetails.INSERT_PURCHASE);){
			java.sql.Date purchaseDate= new  Date( new java.util.Date().getTime());
			
			//preparedStatement.setInt(1, purchaseDetails.getPurchaseId());
			preparedStatement.setString(1, purchaseDetails.getCustname());
			preparedStatement.setString(2, purchaseDetails.getCustMailId());
			preparedStatement.setString(3, purchaseDetails.getCustPhoneNo());
			preparedStatement.setDate(4, purchaseDate);
			preparedStatement.setInt(5, purchaseDetails.getMobileID() );
			
			records = preparedStatement.executeUpdate();
			
			if (records > 0){
				 isInserted = true;
			}
			
		}catch( SQLException sqlEx){
		 throw new MobilePurchaseException(sqlEx.getMessage());
		}
		
		return isInserted;
	}

	@Override
	public boolean deletePurchaseDetail(int mobileId)
			throws MobilePurchaseException {
		int records=0;
		boolean isDeleted = false;
		try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement= 
				connPurchaseDetails.prepareStatement
				(QueryMaperPurchaseDetails.DELETE_PURCHASE);){
			
			
			preparedStatement.setInt(1, mobileId);
			
			
			records = preparedStatement.executeUpdate();
			
			if (records > 0){
				 isDeleted = true;
			}
			
		}catch( SQLException sqlEx){
		 throw new MobilePurchaseException(sqlEx.getMessage());
		}
		
		return isDeleted;
	

	
	}

}
