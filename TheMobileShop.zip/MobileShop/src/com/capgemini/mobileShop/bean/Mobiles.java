package com.capgemini.mobileShop.bean;

public class Mobiles {
	private int mobileId;
	private String name;
	private float price;
	private int quantity;

	public Mobiles() {
	}

	public Mobiles(int mobileid, String name, float price, int quantity) {
		this.mobileId = mobileid;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	public int getMobileid() {
		return mobileId;
	}

	public void setMobileid(int mobileid) {
		this.mobileId = mobileid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Mobiles [mobileid=" + mobileId + ", name=" + name + ", price="
				+ price + ", quantity=" + quantity + "]";
	}

}
