package com.capgemini.mobileShop.service;

import java.util.List;

import com.capgemini.mobileShop.bean.Mobiles;
import com.capgemini.mobileShop.bean.PurchaseDetails;
import com.capgemini.mobileShop.exception.MobilePurchaseException;

public interface IServicePurchaseMobile {
	public boolean insertPurchaseDetails(PurchaseDetails purchaseDetails)
			throws MobilePurchaseException;

}
