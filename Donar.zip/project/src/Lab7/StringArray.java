package Lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class StringArray {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the no. of elements you wish to insert");
		int size = Integer.parseInt(br.readLine());
		String arr[] = new String[size];
for(int counter=0;counter<size;counter++)
{
	System.out.println("Enter the string");
	arr[counter]=br.readLine();
}
Arrays.sort(arr);
for(String s:arr) {
	System.out.println(s);
}
	}

}
