package Lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

public class StringArrayList {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String stop="no";
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		ArrayList<String> productNames = new ArrayList<String>();
		do {
			System.out.println("Enter product name");
		String	name=br.readLine();
			productNames.add(name);
			System.out.println("Do you wish to continue? yes/no");
			stop=br.readLine();
		}while(stop.equalsIgnoreCase("yes"));
	
		Collections.sort(productNames ,new StringComparator());
		
		
for(String pname: productNames) {
	System.out.println(pname);
}
}
}
