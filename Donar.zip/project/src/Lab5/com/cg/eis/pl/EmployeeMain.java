package Lab5.com.cg.eis.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import Lab5.com.cg.igs.service.EmployeeServiceClass;

public class EmployeeMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
          EmployeeServiceClass employeeService = new EmployeeServiceClass();
          BufferedReader br= new BufferedReader(new InputStreamReader(System.in)); 
          System.out.println("name");
           String name= br.readLine();
           System.out.println("employee Id");
           int eid= Integer.parseInt(br.readLine());
           System.out.println("salary");
           double salary=Double.parseDouble(br.readLine());
           System.out.println("designation");
           String designation= br.readLine();
           
           employeeService.getEmployeeDetails(eid, name, salary, designation);
           employeeService.findEmployeeInsurenceScheme();
           employeeService.getDetails();
           
           
	}

}
