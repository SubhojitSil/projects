package Lab5.com.cg.igs.service;

import Lab5.com.cg.igs.bean.Employee;

public class EmployeeServiceClass implements EmployeeService {
	Employee employee = new Employee();

	@Override
	public void getEmployeeDetails(int eid, String name, double salary, String designation) {
		// TODO Auto-generated method stub
		employee.setEmployeeId(eid);
		employee.setName(name);
		employee.setSalary(salary);
		employee.setDesignation(designation);
	}

	@Override
	public void findEmployeeInsurenceScheme() {
		// TODO Auto-generated method stub
double salary=employee.getSalary();
if(salary<5000) {
	employee.setInsuranceScheme("No Scheme");
}
else if(salary>=5000 && salary <20000) {
	employee.setInsuranceScheme("Scheme C");
}else if(salary>=20000 && salary <40000) {
	employee.setInsuranceScheme("Scheme B");
}
else {
	employee.setInsuranceScheme("Scheme A");
}
	}

	@Override
	public void getDetails() {
		// TODO Auto-generated method stub
		System.out.println("ID: " + employee.getEmployeeId() + "\nName: " + employee.getName() + "\nSalary: "
				+ employee.getSalary() + "\nDesignation: " + employee.getDesignation() + "\nInsurence scheme: "
				+ employee.getInsuranceScheme());
	}

}
