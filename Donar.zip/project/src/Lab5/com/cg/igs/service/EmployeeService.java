package Lab5.com.cg.igs.service;

public interface EmployeeService {
//void getEmployeeDetails();
void findEmployeeInsurenceScheme();
void getDetails();
void getEmployeeDetails(int eid, String name, double salary, String designation);
}
