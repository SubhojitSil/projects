/**
 * 
 */
package Lab4;

/**
 * @author subhojit
 *
 */
public class AccountMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Savings smith=new Savings();
		Current kathy=new Current();
		smith.setAccNum();
		smith.setName("Smith");
		smith.setAge(22);
		smith.setBalance(2000);
		
		kathy.setAccNum();
		kathy.setName("Kathy");
		kathy.setAge(24);
		kathy.setBalance(3000);
		System.out.println("Balance while creation");
		smith.toString(smith);
		kathy.toString(kathy);
		smith.deposit(2000);
		kathy.withDraw(6000);
		smith.withDraw(5000);
		System.out.println("Balance After update deposit...");
		smith.toString(smith);
		kathy.toString(kathy);
	}

}
