/**
 * 
 */
package Lab4;

import java.util.Random;

/**
 * @author subhojit
 *
 */
public class Account extends Person{
	private long accNum;
	private double balance;
	private Person accHolder;

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum() {
		Random rnum = new Random();

		this.accNum = rnum.nextInt(2000);
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	void deposit(double balance) {
		this.balance = this.balance + balance;
	}

	void withDraw(double balance) {
		this.balance = this.balance - balance;
	}

	double getbalance() {

		return getBalance();

	}

	void toString(Person p) {
		System.out.println("Name: " + getName() + "\nAccount Number: " + getAccNum() + "\nAge: " + getAge()
				+ "\nBalance: " + getBalance());
		System.out.println("#####################################");

	}
}