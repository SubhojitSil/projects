package Lab4;

public class Savings extends Account{

	final double minimumBalance=1000;
	
	@Override
	void withDraw(double balance) {
		// TODO Auto-generated method stub
		//super.withDraw(balance);
		double balance1=getBalance();
		if((balance1-balance)>minimumBalance)
		{
			setBalance(balance1-balance);
			
		}
		else 
		{
			System.out.println("Sorry unable to proceed");
			System.out.println("*************************");
			}
		
	}

}
