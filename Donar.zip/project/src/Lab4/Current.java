package Lab4;

public class Current extends Account {
	final double overDraftLimit=1000;

	@Override
	void withDraw(double balance) {
		// TODO Auto-generated method stub
		//super.withDraw(balance);
		
		double balance1=getBalance();
		if((balance1-balance)>overDraftLimit)
		{
			setBalance(balance1-balance);
			
		}
		else 
		{
			System.out.println("Sorry unable to proceed");
			System.out.println("*************************");
			}
	}

}
