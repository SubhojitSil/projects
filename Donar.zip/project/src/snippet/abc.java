package snippet;

public class abc {

	
	public String removeDuplicates(String input){
	    String result = "";
	    for (int i = 0; i < input.length(); i++) {
	        if(!result.contains(String.valueOf(input.charAt(i)))) {
	            result += String.valueOf(input.charAt(i));
	        }
	    }
	    return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String x="abxyzxyabc";
abc a=new abc();
String y=a.removeDuplicates(x);
System.out.println(y);
	}
}
