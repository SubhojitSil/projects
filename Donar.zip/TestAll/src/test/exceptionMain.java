package test;



public class exceptionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		selfException sf=null;
		try {
		sf.validate (13);
		} catch (InvalidAgeException m) {
		//	System.out.println("Exception occured: "+m);
		System.err.println("Exception occured:"+m);
		}

		
	}
}
