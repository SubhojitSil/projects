package test;

public class InvalidAgeException extends Exception {
	public InvalidAgeException() {
		// TODO Auto-generated constructor stub
		super();
	}

}
