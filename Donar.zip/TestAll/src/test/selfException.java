package test;


	
public class selfException {

	static void validate(int age)throws InvalidAgeException{  
	     if(age<18)  
	      throw new InvalidAgeException();  
	     else  
	      System.out.println("you can vote");  
	   }  

}
