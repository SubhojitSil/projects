package com.bvk.client;

public class NestedTryBlocks {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			try {

				int a[] = {10,20,30};
				
				for(int i = 0 ; i < 5 ; i++) {
					System.out.println(a[i]);
				}
				
			} catch (ArrayIndexOutOfBoundsException ex) {
				System.out
						.println("Inside Array Index Out of Bounds Exception");
				int x = 10 / 0;
			} finally {
				System.out.println("finally of ArrayIndexOutOfBoundsException");
			}
		} catch (ArithmeticException ae) {
			System.out.println("Inside ArithmeticException");
		} finally {
			System.out.println("finally of ArithmeticException");
		}
		System.out.println("Exit main");
	}
}