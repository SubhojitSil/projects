package com.project.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.CourseDao;
import com.project.model.CourseInfo;
import com.project.model.PaymentInfo;


@WebServlet("/UpdateDuePaymentServlet")
public class UpdateDuePaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateDuePaymentServlet() {
        super();
 
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PaymentInfo upobj=new PaymentInfo();
		upobj.setSuid(request.getParameter("suid"));
		upobj.setPayment_status(request.getParameter("cpay"));
		//CALLING DAO
		CourseDao cup=new CourseDao();
		boolean f=cup.updatepayment(upobj);
		
		
		response.setContentType("text/html");
		
		if(f)
		{
			
			response.sendRedirect("DisplayDuePaymentServlet");
		}
		else
		{
			request.setAttribute("ERRORMSG3", "INVALID Student ID");
			RequestDispatcher rd = request.getRequestDispatcher("UpdateDuePayment.jsp");
			rd.forward(request, response);
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
