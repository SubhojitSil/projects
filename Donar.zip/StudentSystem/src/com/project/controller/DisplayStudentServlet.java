package com.project.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.CourseDao;
//import com.project.model.CourseInfo;
import com.project.model.StudentInfo;


@WebServlet("/DisplayStudentServlet")
public class DisplayStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DisplayStudentServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//create object of dao class
		CourseDao scd=new CourseDao();
		//call dao&reciecve arraylist object
		ArrayList<StudentInfo>dslist=scd.displaystudentc();
		//put array list object inside request object(key value)
		
		request.setAttribute("aslist", dslist);
		//create link requset object to jsp file
		
RequestDispatcher rd=request.getRequestDispatcher("DisplayStudent.jsp");
//forward to jsp file
rd.forward(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
