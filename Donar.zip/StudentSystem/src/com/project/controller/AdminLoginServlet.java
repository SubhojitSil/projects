package com.project.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.dao.AdminDao;
import com.project.model.AdminInfo;


@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AdminLoginServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("adminname");
		String pass = request.getParameter("password");

		AdminDao admo=new AdminDao();
		AdminInfo cobj= admo.loginCheck(uid, pass);

		
		if(cobj  != null)
		{    HttpSession session = request.getSession(true);
		session.setAttribute("admininfo", cobj);
			//out.print("<h1>VALID USER</h1>");
			response.sendRedirect("AfterLogin.jsp");
			
		}
		else
		{
			//out.print("<h1>INVALID USER</h1>");
		request.setAttribute("ERRORMSG", "INVALID USER OR PASSWORD");
		RequestDispatcher rd = request.getRequestDispatcher("AdminLogin.jsp");
		rd.forward(request, response);
		}
			
		//out.close();
 	}
	
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
