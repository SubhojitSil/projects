package com.project.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.CourseDao;

import com.project.model.PaymentInfo;


@WebServlet("/DisplayDuePaymentServlet")
public class DisplayDuePaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DisplayDuePaymentServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//create object of dao class
		CourseDao cdo=new CourseDao();
		//call dao&reciecve arraylist object
		ArrayList<PaymentInfo>paylist=cdo.displayAlldue();
		//put array list object inside request object(key value)
		
		request.setAttribute("plist", paylist);
		//create link requset object to jsp file
		
RequestDispatcher rd=request.getRequestDispatcher("DisplayDuePayment.jsp");
//forward to jsp file
rd.forward(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
