
package com.project.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.AdminDao;
import com.project.model.AdminInfo;

@WebServlet("/AdminRegistrationServlet")
public class AdminRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AdminRegistrationServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		AdminInfo adobj = new AdminInfo();
		adobj.setAdminname(request.getParameter("adminname"));
		adobj.setPassword(request.getParameter("password"));
		// CALLING DAO
		AdminDao adao = new AdminDao();
		boolean f = adao.insertRecord(adobj);

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if (f) {
			out.print("inserted");
		} else {
			out.print("not inserted");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// doGet(request, response);
	}

}
