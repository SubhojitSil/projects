package com.project.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.CourseDao;

import com.project.model.CourseInfo;

@WebServlet("/AddCourseServlet")
public class AddCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AddCourseServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		CourseInfo cobj = new CourseInfo();
		cobj.setCname(request.getParameter("cname"));
		cobj.setCtime(request.getParameter("ctime"));
		cobj.setCmax(request.getParameter("cmax"));
		cobj.setCinit(request.getParameter("cinit"));
		cobj.setCloc(request.getParameter("cloc"));
		cobj.setCstart(request.getParameter("cstart"));
		cobj.setCend(request.getParameter("cend"));
		cobj.setCpay(request.getParameter("cpay"));
		// CALLING DAO
		CourseDao crdao = new CourseDao();
		boolean f = crdao.insertCourse(cobj);

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if (f) {
			out.print("COURSE ADDED");
			response.sendRedirect("AfterLogin.jsp");
		} else {
			out.print("TRY AGAIN");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
