package com.project.controller;

import java.io.IOException;
//import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.CourseDao;
import com.project.model.CourseInfo;


@WebServlet("/UpdateCourseServlet")
public class UpdateCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateCourseServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CourseInfo cbj=new CourseInfo();
		cbj.setCid(request.getParameter("cid"));
		cbj.setCmax(request.getParameter("cmax"));
		//CALLING DAO
		CourseDao cuo=new CourseDao();
		boolean f=cuo.updatecourse(cbj);
		
		
		response.setContentType("text/html");
		//PrintWriter out=response.getWriter();
		if(f)
		{
			
			response.sendRedirect("DisplayAllCourseServlet");
		}
		else
		{
			request.setAttribute("ERRORMSG1", "INVALID Course ID");
			RequestDispatcher rd = request.getRequestDispatcher("UpdateCourse.jsp");
			rd.forward(request, response);
		}

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
