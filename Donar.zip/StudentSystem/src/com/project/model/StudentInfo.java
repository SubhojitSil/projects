package com.project.model;

import java.io.Serializable;

public class StudentInfo implements Serializable {
	private String cid;
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	private String sid;
public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
private String sname;
private String spassword;
private String semail;
private String sphoneno;
private String scollege;
private String saddress;
private String dob;
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getSpassword() {
	return spassword;
}
public void setSpassword(String spassword) {
	this.spassword = spassword;
}
public String getSemail() {
	return semail;
}
public void setSemail(String semail) {
	this.semail = semail;
}
public String getSphoneno() {
	return sphoneno;
}
public void setSphoneno(String sphoneno) {
	this.sphoneno = sphoneno;
}
public String getScollege() {
	return scollege;
}
public void setScollege(String scollege) {
	this.scollege = scollege;
}
public String getSaddress() {
	return saddress;
}
public void setSaddress(String saddress) {
	this.saddress = saddress;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}

}
