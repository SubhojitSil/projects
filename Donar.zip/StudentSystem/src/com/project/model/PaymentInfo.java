package com.project.model;

import java.io.Serializable;

public class PaymentInfo implements Serializable{
	private String cid;
	private String suid;
private String payment_status;
public String getCid() {
	return cid;
}
public void setCid(String cid) {
	this.cid = cid;
}
public String getSuid() {
	return suid;
}
public void setSuid(String suid) {
	this.suid = suid;
}
public String getPayment_status() {
	return payment_status;
}
public void setPayment_status(String payment_status) {
	this.payment_status = payment_status;
}
}
