package com.project.model;

import java.io.Serializable;

public class CourseInfo implements Serializable{
private String cid;
private String cname;
private String ctime;
private String cmax;
private String cinit;
private String cpay;
public String getCpay() {
	return cpay;
}
public void setCpay(String cpay) {
	this.cpay = cpay;
}
public String getCid() {
	return cid;
}
public void setCid(String cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getCtime() {
	return ctime;
}
public void setCtime(String ctime) {
	this.ctime = ctime;
}
public String getCmax() {
	return cmax;
}
public void setCmax(String cmax) {
	this.cmax = cmax;
}
public String getCinit() {
	return cinit;
}
public void setCinit(String cinit) {
	this.cinit = cinit;
}
public String getCloc() {
	return cloc;
}
public void setCloc(String cloc) {
	this.cloc = cloc;
}
public String getCstart() {
	return cstart;
}
public void setCstart(String cstart) {
	this.cstart = cstart;
}
public String getCend() {
	return cend;
}
public void setCend(String cend) {
	this.cend = cend;
}
private String cloc;
private String cstart;
private String cend;
}
