package com.project.model;

public class Studentlist {
private String cid;
private String payment_status;
private String sname;
private String semail;
private String sid;
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public String getCid() {
	return cid;
}
public void setCid(String cid) {
	this.cid = cid;
}
public String getPayment_status() {
	return payment_status;
}
public void setPayment_status(String payment_status) {
	this.payment_status = payment_status;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getSemail() {
	return semail;
}
public void setSemail(String semail) {
	this.semail = semail;
}
public String getSphoneno() {
	return sphoneno;
}
public void setSphoneno(String sphoneno) {
	this.sphoneno = sphoneno;
}
public String getScollege() {
	return scollege;
}
public void setScollege(String scollege) {
	this.scollege = scollege;
}
public String getSaddress() {
	return saddress;
}
public void setSaddress(String saddress) {
	this.saddress = saddress;
}
private String sphoneno;
private String scollege;
private String saddress;

}
