package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.model.AdminInfo;
import com.project.model.BookSeat;

public class BookSeatStudent {
	public boolean bookSeat(BookSeat aobj) {
		boolean f = false;

		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();

			pst = con.prepareStatement("insert into payment_status values(?,?,?)");

			pst.setInt(1, aobj.getCid());
			pst.setInt(2, aobj.getSid());
			pst.setString(3,aobj.getStatus());
			int i = pst.executeUpdate();

			if (i > 0)
				f = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return f;

	}
}



