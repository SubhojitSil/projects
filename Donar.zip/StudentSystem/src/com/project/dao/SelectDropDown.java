package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.project.model.CourseInfo;

public class SelectDropDown {
	
	ArrayList<CourseInfo> courselist = new ArrayList<CourseInfo>();
	PreparedStatement pst = null;
	Connection con = null;
	public ArrayList<CourseInfo> selectDropDown(String cname){
		
	try {
		con = DBConnection.getMySQlConnection();
		pst = con.prepareStatement("select * from course where Cname=?");
		pst.setString(1,cname );
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			// create objetct
			CourseInfo obj = new CourseInfo();
			// extract value from resultset & store in object
			obj.setCid(rs.getString(1));
			obj.setCname(rs.getString(2));
			obj.setCtime(rs.getString(3));
			obj.setCmax(rs.getString(4));
			obj.setCinit(rs.getString(5));
			obj.setCloc(rs.getString(6));
			obj.setCstart(rs.getString(7));
			obj.setCend(rs.getString(8));
			courselist.add(obj);
		}
	} catch (SQLException e) {
		e.printStackTrace();

	}
	return courselist;
}


}
