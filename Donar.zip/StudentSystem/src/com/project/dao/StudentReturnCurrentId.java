package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.project.model.StudentInfo;

public class StudentReturnCurrentId {
	public int studentReturnCurrentId() {
		int id=0;
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement("select suid from student_information");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
}