package com.project.dao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.CourseDao;
import com.project.model.CourseInfo;



@WebServlet("/CourseDelete")
public class CourseDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CourseDelete() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	CourseInfo csobj=new CourseInfo();
		csobj.setCid(request.getParameter("cid"));
		
		//CALLING DAO
				CourseDao co=new CourseDao();
				boolean f=co.deleteRecord(csobj);
				
				
				response.setContentType("text/html");
				PrintWriter out=response.getWriter();
				if(f)
				{
					out.print("deleted");
				}
				else
				{
					out.print("invalid data");
				}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
