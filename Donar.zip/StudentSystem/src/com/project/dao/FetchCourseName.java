package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.TreeSet;

import com.project.model.CourseInfo;

public class FetchCourseName {

	TreeSet<CourseInfo> courselist = new TreeSet<CourseInfo>();
	PreparedStatement pst = null;
	Connection con = null;

	public TreeSet<String> FetchCourse() {

		TreeSet<String> clist = new TreeSet<String>();
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement("select cid from course");
			//pst.setString();
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
					clist.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return clist;
	}

}
