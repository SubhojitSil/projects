package com.project.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.ArrayList;

import com.project.model.AdminInfo;


public class AdminDao {


	public boolean insertRecord(AdminInfo aobj) {
		boolean f = false;

		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();

			pst = con.prepareStatement("insert into admin values(?,?)");

			pst.setString(1, aobj.getAdminname());
			pst.setString(2, aobj.getPassword());
			int i = pst.executeUpdate();

			if (i > 0)
				f = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return f;
}
	

	public AdminInfo loginCheck(String uid, String pass) {
		//boolean f = false;
		AdminInfo cobj=null;
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();

			pst = con.prepareStatement("select * from admin where username=? and password=?");

			pst.setString(1, uid);
			pst.setString(2, pass);
			ResultSet rs = pst.executeQuery();
			if (rs.next())
			{
				   cobj = new AdminInfo();
			     cobj.setAdminname(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return cobj;
	
	
}
}
