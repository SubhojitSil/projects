package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.project.model.CourseInfo;
import com.project.model.StudentInfo;

public class DisplayPaymentStatus {
	public String PaymentStatus(String userid) {
		String s = null;
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement("select payment_status from payment_status where sid=?");
			//pst.setString();
			pst.setString(1, userid);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
					 s=(rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();}
		return s;
	}
	}

	

