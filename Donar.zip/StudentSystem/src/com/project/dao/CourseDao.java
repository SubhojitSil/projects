package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.project.model.CourseInfo;
import com.project.model.PaymentInfo;
import com.project.model.StudentInfo;
import com.project.model.Studentlist;
import com.project.dao.DBConnection;

public class CourseDao {
	public boolean insertCourse(CourseInfo cf) {
		boolean f = false;

		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();

			pst = con.prepareStatement(
					"insert into course(cname,ctime,cmax,cinit,cloc,cstart,cend,cpay) values(?,?,?,?,?,?,?,?)");

			pst.setString(1, cf.getCname());
			pst.setString(2, cf.getCtime());
			pst.setString(3, cf.getCmax());
			pst.setString(4, cf.getCinit());
			pst.setString(5, cf.getCloc());
			pst.setString(6, cf.getCstart());
			pst.setString(7, cf.getCend());
			pst.setString(8, cf.getCpay());
			int i = pst.executeUpdate();

			if (i > 0)
				f = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return f;

	}

	public ArrayList<CourseInfo> displayAllCourse() {

		ArrayList<CourseInfo> courselist = new ArrayList<CourseInfo>();
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement("select * from course");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				// create objetct
				CourseInfo obj = new CourseInfo();
				// extract value from resultset & store in object
				obj.setCid(rs.getString(1));
				obj.setCname(rs.getString(2));
				obj.setCtime(rs.getString(3));
				obj.setCmax(rs.getString(4));
				obj.setCinit(rs.getString(5));
				obj.setCloc(rs.getString(6));
				obj.setCstart(rs.getString(7));
				obj.setCend(rs.getString(8));
				obj.setCpay(rs.getString(9));
				courselist.add(obj);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return courselist;

	}

	public boolean deleteRecord(CourseInfo csobj) {
		boolean f = false;

		PreparedStatement pst = null;
		// PreparedStatement ps=null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			/*
			 * ps=con.prepareStatement("select cinit from course where cid=?");
			 * String s=ps.setString(1, csobj.getCid()); int
			 * j=Integer.parseInt();
			 */

			pst = con.prepareStatement("delete from course where cid =?");
			pst.setString(1, csobj.getCid());
			int i = pst.executeUpdate();

			if (i > 0)
				f = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return f;
	}

	public boolean updatecourse(CourseInfo cu) {
		boolean f = false;

		PreparedStatement pst = null;

		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();

			pst = con.prepareStatement("update course set cmax=? where cid =?");
			pst.setString(1, cu.getCmax());
			pst.setString(2, cu.getCid());
			int i = pst.executeUpdate();

			if (i > 0)
				f = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return f;
	}

	public ArrayList<PaymentInfo> displayAlldue() {

		ArrayList<PaymentInfo> paylist = new ArrayList<PaymentInfo>();
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement("select * from payment_status where payment_status='f'");
			ResultSet rsp = pst.executeQuery();
			while (rsp.next()) {
				// create objetct
				PaymentInfo pobj = new PaymentInfo();
				// extract value from resultset & store in object
				pobj.setCid(rsp.getString(1));
				pobj.setSuid(rsp.getString(2));
				pobj.setPayment_status(rsp.getString(3));

				paylist.add(pobj);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return paylist;

	}

	public ArrayList<Studentlist> displaystudent(String cid) {

		ArrayList<Studentlist> studentlist = new ArrayList<Studentlist>();
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement(
					"select student_information.suid,susrname,semail from student_information,payment_status where student_information.suid=payment_status.suid and payment_status=? and cid=?");
			pst.setString(1, "t");
			pst.setString(2, cid);
			ResultSet rsp = pst.executeQuery();
			while (rsp.next()) {
				// create objetct
				Studentlist sobj = new Studentlist();
				// extract value from resultset & store in object
				sobj.setSid(rsp.getString(1));
				sobj.setSname(rsp.getString(2));
				sobj.setSemail(rsp.getString(3));
				sobj.setCid(rsp.getString(4));
				sobj.setPayment_status(rsp.getString(5));

				studentlist.add(sobj);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return studentlist;

	}

	public boolean updatepayment(PaymentInfo cp) {
		boolean f = false;

		PreparedStatement pst = null;

		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();

			pst = con.prepareStatement("update payment_status set payment_status=? where suid =?");
			pst.setString(1, cp.getPayment_status());
			pst.setString(2, cp.getSuid());
			int i = pst.executeUpdate();

			if (i > 0)
				f = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return f;
	}

	public ArrayList<StudentInfo> displaystudentc() {

		ArrayList<StudentInfo> dslist = new ArrayList<StudentInfo>();
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement(
					"select susername,semail,saddress,scollege,sphoneno,cid from student_information,payment_status where student_information.suid=payment_status.suid and payment_status.payment_status='t'");
			// pst.setString(1, "t");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				// create objetct
				StudentInfo dsobj = new StudentInfo();
				// extract value from resultset & store in object
				dsobj.setSname(rs.getString(1));
				dsobj.setSemail(rs.getString(2));
				dsobj.setSaddress(rs.getString(3));
				dsobj.setScollege(rs.getString(4));
				dsobj.setSphoneno(rs.getString(5));
				dsobj.setCid(rs.getString(6));
				dslist.add(dsobj);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return dslist;

	}

	public ArrayList<StudentInfo> displaystudentf() {

		ArrayList<StudentInfo> fslist = new ArrayList<StudentInfo>();
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement(
					"select susername,semail,saddress,scollege,sphoneno,cid from student_information,payment_status where student_information.suid=payment_status.suid and payment_status.payment_status='f'");
			// pst.setString(1, "f");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				// create objetct
				StudentInfo fsobj = new StudentInfo();
				// extract value from resultset & store in object
				fsobj.setSname(rs.getString(1));
				fsobj.setSemail(rs.getString(2));
				fsobj.setSaddress(rs.getString(3));
				fsobj.setScollege(rs.getString(4));
				fsobj.setSphoneno(rs.getString(5));
				fsobj.setCid(rs.getString(6));
				fslist.add(fsobj);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return fslist;

	}
	public ArrayList<PaymentInfo> checkstatus( String sid) {

		ArrayList<PaymentInfo>payclist = new ArrayList<PaymentInfo>();
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement(
					"select cid,payment_status from payment_status where suid=?");
			pst.setString(1, sid );
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				// create objetct
				PaymentInfo pcobj = new PaymentInfo();
				// extract value from resultset & store in object
				pcobj.setCid(rs.getString(1));
				pcobj.setPayment_status(rs.getString(2));
				payclist.add(pcobj);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return payclist;
}
}
