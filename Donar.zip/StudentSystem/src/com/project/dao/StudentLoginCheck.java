package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.project.dao.DBConnection;
import com.project.model.StudentInfo;

public class StudentLoginCheck {
	public StudentInfo loginCheck(String uid, String pass) {
		StudentInfo sinfo = null;
		PreparedStatement pst = null;
		Connection con = null;
		try {
			con = DBConnection.getMySQlConnection();
			pst = con.prepareStatement("select * from student_information where suid=? and spassword=?");

			pst.setString(1, uid);
			pst.setString(2, pass);

			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				sinfo = new StudentInfo();
				// f = true;
				sinfo.setSname(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return sinfo;
	}

}
