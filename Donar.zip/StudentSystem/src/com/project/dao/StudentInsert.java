package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.DBConnection;
import com.project.model.StudentInfo;

public class StudentInsert {
	public boolean insertRecord(StudentInfo cobj) 
	{
		boolean f= false;
		PreparedStatement pst = null;
		   Connection con = null;
		   try
			{
			   con = DBConnection.getMySQlConnection();
			   
			   pst = con.prepareStatement("insert into student_information(susername,spassword,semail,sphoneno,scollege,saddress,sdob)  values(?,?,?,?,?,?,?)");
				     
			   pst.setString(1, cobj.getSname());
			   pst.setString(2, cobj.getSpassword());
			   pst.setString(3, cobj.getSemail());
			   pst.setString(4, cobj.getSphoneno());
			   pst.setString(5, cobj.getScollege());
			   pst.setString(6, cobj.getSaddress());
			   pst.setString(7, cobj.getDob());
			   
			   int i = pst.executeUpdate();
				     
			   if(i > 0 )
				   f=true;
				 // System.out.println("DATA INSERTED");
		     }catch(SQLException e){e.printStackTrace();
		     }
		   return f;
		  }
	

}
