package com.cproject.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.BookSeatStudent;
import com.project.dao.StudentReturnCurrentId;
import com.project.model.BookSeat;

/**
 * Servlet implementation class BookCourseServlet
 */
@WebServlet("/BookCourseServlet")
public class BookCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookCourseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		BookSeat bs= new BookSeat();
		String sid=request.getParameter("sid");
		int ssid=Integer.parseInt(sid);
		String cid=request.getParameter("cid");
		int ccid=Integer.parseInt(cid);
		String s="f";
		
		bs.setSid(ssid);
		bs.setCid(ccid);
		bs.setStatus(s);
		BookSeatStudent bss= new BookSeatStudent();
		boolean f= bss.bookSeat(bs);
		if (f)
		{
			request.setAttribute("CONFIRM MSG", "Your seat is prebooked and pending for approval");
			RequestDispatcher rd=request.getRequestDispatcher("AfterLoginStudent.jsp");
			rd.forward(request, response);
			}else
		{
				request.setAttribute("CONFIRM MSG", "oops something went wrong try again later");
				RequestDispatcher rd=request.getRequestDispatcher("BookCourse.jsp");
				rd.forward(request, response);
		
			//out.print("oops something went wrong try again later");
		}
	}
		
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
