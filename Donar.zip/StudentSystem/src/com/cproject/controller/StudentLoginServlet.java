package com.cproject.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.dao.*;
import com.project.dao.StudentLoginCheck;
import com.project.model.StudentInfo;

/**
 * Servlet implementation class StudentLoginServlet
 */
@WebServlet("/StudentLoginServlet")
public class StudentLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uid = request.getParameter("userid");
		String pass = request.getParameter("password");
		
		//CREATE OBJECT OF DAO CLASS
		StudentLoginCheck cdao = new StudentLoginCheck();
				
		//CALL DML LOGIN CHECK METHOD 
		//boolean f = cdao.loginCheck(uid, pass);
		StudentInfo	 info=cdao.loginCheck(uid, pass);	
		//AFTER GETTING REPLY FROM DAO
		//response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
				
		if(info !=null)
		{
			//out.print("VALID USER");
			HttpSession session= request.getSession(true);
			session.setAttribute("CurrUser", info);
			response.sendRedirect("AfterLoginStudent.jsp");
		}	
		else
		{
			//out.print("NOT VALID");
			request.setAttribute("ERRORMSG", "Please enter a valid ID and PASSWORD");
			RequestDispatcher rd=request.getRequestDispatcher("StudentLogin.jsp");
			rd.forward(request, response);
		}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
