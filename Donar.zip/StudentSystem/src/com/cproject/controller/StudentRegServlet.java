package com.cproject.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.model.StudentInfo;
import com.project.dao.*;

/**
 * Servlet implementation class StudentRegServlet
 */
@WebServlet("/StudentRegServlet")
public class StudentRegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentRegServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username= request.getParameter("sname");
		String password= request.getParameter("spassword");
		String email= request.getParameter("semail");
		String phoneno= request.getParameter("sphone");
		String college= request.getParameter("scollege");
		String address= request.getParameter("saddress");
		String dob= request.getParameter("sdob");
		
		StudentInfo sinfo= new StudentInfo();
		sinfo.setSname(username);
		sinfo.setSpassword(password);
		sinfo.setSemail(email);
		sinfo.setSphoneno(phoneno);
		sinfo.setScollege(college);
		sinfo.setSaddress(address);
		sinfo.setDob(dob);
		//calling dao
		
		StudentInsert cinfo= new StudentInsert();
		boolean f=cinfo.insertRecord(sinfo);
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		if (f)
		{
			StudentReturnCurrentId currentId= new StudentReturnCurrentId();
			int sid=currentId.studentReturnCurrentId();
			request.setAttribute("ERRORMSG", "Your sid is: "+sid+" please note it for login");
			RequestDispatcher rd=request.getRequestDispatcher("StudentLogin.jsp");
			rd.forward(request, response);
			}else
		{
				request.setAttribute("ERRORMSG", "oops something went wrong try again later");
				RequestDispatcher rd=request.getRequestDispatcher("StudentReg.jsp");
				rd.forward(request, response);
		
			out.print("oops something went wrong try again later");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
