package com.cproject.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.CourseDao;
import com.project.dao.SelectDropDown;
import com.project.model.CourseInfo;



@WebServlet("/DisplayDropdownCourse")
public class DisplayDropdownCourse extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DisplayDropdownCourse() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//create object of dao class
		CourseInfo cbj=new CourseInfo();
		String cname=(request.getParameter("selectspecific"));
		SelectDropDown cd=new SelectDropDown();
		//call dao&reciecve arraylist object
		ArrayList<CourseInfo>courselist=cd.selectDropDown(cname);
		//put array list object inside request object(key value)
		
		request.setAttribute("clist", courselist);
		//create link requset object to jsp file
		
RequestDispatcher rd=request.getRequestDispatcher("DisplaySpecific.jsp");
//forward to jsp file
rd.forward(request,response);
	}

	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
