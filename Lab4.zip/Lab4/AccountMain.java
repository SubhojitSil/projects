/**
 * 
 */
package Lab4;

/**
 * @author subsil
 *
 */
public class AccountMain {

	public static void main(String args[]) {
		Savings smith = new Savings();
		Current kathy = new Current();

		smith.setAccNum();
		smith.setName("Smith");
		smith.setAge(22);
		smith.setBalance(2000);

		kathy.setAccNum();
		kathy.setName("Kathy");
		kathy.setAge(25);
		kathy.setBalance(3000);

		System.out.println("Balance after creation");
		System.out.println(smith);
		System.out.println(kathy);
		smith.withDraw(1000);
		kathy.withDraw(1000);
		System.out.println("Balance after transaction");
		System.out.println(smith);
		System.out.println(kathy);

	}

}
