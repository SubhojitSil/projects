/**
 * 
 */
package Lab4;

/**
 * @author subsil
 *
 */
public class Current extends Account {
	final double overDraftLimit=1000;

	@Override
	void withDraw(double amount) {
		// TODO Auto-generated method stub
		//super.withDraw(amount);
		
		double balance1=getBalance();
		
		if((balance1-amount)>overDraftLimit)
		{
			setBalance(balance1-amount);;
		}
		else 
		{
			System.out.println("SORRY UNABLE TO PROCEED DUE TO OVERDRAFT LIMIT REACHED");
			System.out.println("****************************************");
		}
	}
	
	

}
